<?php
include_once 'menu.php';
include_once("dbConnection.php");
include_once ('util.php');

// Function to check if the user is not already registered
function isNotRegistered($phoneNumber, $con) {
    $count = 0; // Initialize $count variable
    $stmt = $con->prepare("SELECT COUNT(*) FROM user WHERE mob= ?");
    if (!$stmt) {
        echo "END Database error: " . $con->error;
        exit();
    }
    $stmt->bind_param('s', $phoneNumber); // Bind the parameter
    $stmt->execute();
    $stmt->bind_result($count); // Bind the result
    $stmt->fetch(); // Fetch the result into $count
    $stmt->close(); // Close the statement
    return $count == 0; 
}

// Check if 'from' and 'text' keys exist in the $_POST array
if(isset($_POST['from']) && isset($_POST['text'])) {
    $phoneNumber = $_POST['from'];
    $text = $_POST['text']; 

    $textArray = explode(" ", $text);

    // Check if all required parameters are present in the SMS
    if(count($textArray) >= 6) {
        $name = $textArray[0];
        $gender = $textArray[1];
        $college = $textArray[2];
        $email = $textArray[3];
        $mob = $textArray[4];
        $password = $textArray[5];

        if(isNotRegistered($phoneNumber, $con)) {
            $stmt = $con->prepare("INSERT INTO user (name, gender, college, email, mob, password) VALUES (?, ?, ?, ?, ?, ?)");
            if (!$stmt) {
                echo "END Database error: " . $con->error;
                exit();
            }
            $stmt->bind_param('ssssss', $name, $gender, $college, $email, $phoneNumber, $password);

            if ($stmt->execute()) {
                $result = $con->query("SELECT * FROM user WHERE name = '$name'");
                if (!$result) {
                    echo "END Database error: " . $con->error;
                    exit();
                }
                if ($result->num_rows > 0) {
                    while($value = $result->fetch_assoc()) {
                        echo "END Thank you $name, you have been successfully registered!";
                    }
                } else {
                    echo "END User not found after registration.";
                }
            } else {
                echo "END Registration failed. Please try again later.";
            }
        } else {
            echo "END User is already registered.";
        }
    } else {
        // If name or password is missing in the SMS, prompt the user to provide both
        echo "END Your SMS must contain name, gender, college, email, mobile number, and password.";
    }
} else {
    // If 'from' or 'text' keys are missing in the $_POST array, prompt the user to provide them
    echo "END Please provide 'from' and 'text' parameters.";
}
?>
