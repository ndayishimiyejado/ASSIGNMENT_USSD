<?php
class QuizApp {
    protected $questions = [
        1 => "What is the capital of France?",
        2 => "Who wrote 'Romeo and Juliet'?",
        // Add more questions here
    ];

    protected $options = [
        1 => ["Paris", "London", "Berlin", "Madrid"],
        2 => ["William Shakespeare", "Jane Austen", "Charles Dickens", "Mark Twain"],
        // Add options for each question
    ];

    protected $currentQuestion = 1;

    public function displayQuestion() {
        echo "CON " . $this->questions[$this->currentQuestion] . "\n";
        foreach ($this->options[$this->currentQuestion] as $key => $option) {
            echo $key + 1 . ". " . $option . "\n";
        }
    }

    public function processAnswer($selectedOption) {
        // Process the user's answer here
        // You can check if the selected option is correct and update the score

        // Move to the next question
        $this->currentQuestion++;

        // Display the next question or end the quiz
        if (isset($this->questions[$this->currentQuestion])) {
            $this->displayQuestion();
        } else {
            echo "END Thank you for taking the quiz!";
        }
    }
}

// Usage example
$quiz = new QuizApp();

$textArray = [1, "start", "english test", "q1", "1"]; // Simulated user input
$level = count($textArray);

if ($level == 5 && $textArray[3] == "q1") {
    $selectedOption = $textArray[4];
    $quiz->processAnswer($selectedOption);
} else {
    $quiz->displayQuestion();
}
?>