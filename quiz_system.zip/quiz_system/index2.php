<?php
    include_once 'menu.php';
    include_once 'dbConnection.php';
    include_once 'util.php';
    $sessionId = $_POST['sessionId'];
    $phoneNumber = $_POST['phoneNumber'];
    $serviceCode = $_POST['serviceCode'];
    $text = $_POST['text'];
    // Include necessary files and classes
    
    // Initialize the menu object
    $menu = new Menu($text, $sessionId);
    $text = $menu->middleware($text);
    $isRegistered= $menu->isRegistered($phoneNumber);
    //var_dump((bool)$isRegistered);
    

    // Check if the user is not registered

    if ($text == "" && !$isRegistered) {
        // Show the main menu for unregistered users
        $menu->mainMenuUnRegistered();
    }else if(!$isRegistered){
        
        $textArray=explode("*", $text);
        $menu->menuRegister($textArray,$phoneNumber);
                
    } else {
        
        if ($text == "") {
            
            $menu->mainMenuRegistered();
        } else {
            $textArray=explode("*", $text);
            switch ( $textArray[0]) {   
                case 1:
                    // Handle taking exam
                   $menu->menuTakeExam($textArray,$phoneNumber);
                   break;
                    
                case 2:
                    // Handle viewing results
                    $menu->menuViewResults($textArray,$phoneNumber);
                    break;
                case 3:
                    // Handle logout
                    //$menu->menuLogout();
                    break;
                default:
                    echo "END Invalid choice, please retry";
            }
        }
    }
