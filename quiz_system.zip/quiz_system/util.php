<?php
    class Util{
        //About static variables
        static $GO_BACK = "98.";
        static $GO_TO_MAIN_MENU = "99.";
}
?>