<?php
class Menu{
    
    protected $text;
    protected $sessionId;
    protected $conn; // Database connection

    function __construct($text, $sessionId){
        $this->text = $text;
        $this->sessionId = $sessionId;

        // Establish a database connection
        $this->conn = new PDO("mysql:host=localhost;dbname=project1", "root", "");
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    function isOptionTrue($optionId) {
        // Assuming $this->conn represents your database connection object
        $stmt = $this->conn->prepare("SELECT * FROM options WHERE optionid = :opid");
        $stmt->bindParam(':opid', $optionId);
        $stmt->execute();
    
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // If option is found
        if ($result) {
            return $result['optionid']; 
        } else {
           
            return false;
        }
    }

    function isQuestionIncluded($questionId, $conn) {
        // Prepare the SQL query to select the question from the questions table
        $stmt = $conn->prepare("SELECT * FROM questions WHERE qid = :qid");
        $stmt->bindParam(':qid', $questionId);
        $stmt->execute();
    
        // Fetch the result
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
        // If question is found
        if ($result) {
            return $result['qid'];
        } else {
            // If question is not found
            return false;
        }
    }
    function isOptionCorrect($qid, $conn) {
        // Prepare the SQL query to select the answer from the answers table
        $stmt = $conn->prepare("SELECT * FROM answer WHERE qid = :qid");
        $stmt->bindParam(':qid', $qid);
        $stmt->execute();
    
        // Fetch the result
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
        // If answer is found
        if ($result) {
            return $result['ansid']; // Check if is_correct is 1 for correct, otherwise false
        } else {
            // If answer is not found
            return false;
        }
    }
    

    public function mainMenuRegistered(){
        $response = "CON Welcome to Online Examination System\n";
        $response .= "1. Take quiz\n";
        $response .= "2.  View score\n";
        echo $response;
        
    }

    public function mainMenuUnRegistered(){
        $response = "CON Welcome to Online Examination System\n";
        $response .= "1. Register\n";
        echo $response;
    }

    public function menuRegister($textArray,$phoneNumber){
        $level = count($textArray);
        if ($level == 1) {
            echo "CON Welcome to Online Examination System Registration\n";
            echo "Enter your Name:";
        } 
        elseif ($level == 2) {
            echo "CON Select your Gender:\n";
            echo "1. Male\n";
            echo "2. Female\n";
        } 
        elseif ($level == 3) {
            echo "CON Enter your Email:";
        } 
        elseif ($level == 4) {
            // Fetch colleges from the database
        $stmt = $this->conn->query("SELECT college_name FROM colleges");
        $colleges = $stmt->fetchAll(PDO::FETCH_COLUMN);
        // Display colleges as options
        echo "CON Select your College:\n";
        foreach ($colleges as $key => $college) {
            echo ($key + 1) . ". $college\n";
        }
        } 
        elseif ($level == 5) {
            echo "CON Enter your Mobile Number:";
        } 
        elseif ($level == 6) {
            echo "CON Enter your Password:";
        } 
        elseif ($level == 7) {
            $name = $textArray[1];
            $gender = strtoupper($textArray[2]);
            $email = $textArray[3];
            $college = $textArray[4];
            $mobile = $textArray[5];
            $password = md5($textArray[6]);

            $stmt = $this->conn->prepare("INSERT INTO user (name, gender, email, college, mob, password) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$name, $gender, $email, $college, $mobile, $password]);
    
            if ($stmt->rowCount() > 0) {
                echo "END $name Registration  done successful. You can now login.";
            } else {
                echo "END Registration failed. Please try again.";
            }
        }
    }
    
    public function menuViewSchedule(){
      
        $stmt = $this->conn->query("SELECT * FROM exam_schedule");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $response = "CON Exam Schedule:\n";
        foreach($rows as $row) {
            $response .= $row['exam_date'] . " - " . $row['exam_name'] . "\n";
        }
        echo $response;
    }

    public function isRegistered($phoneNumber){
        $stmt = $this->conn->prepare("SELECT * FROM user WHERE mob = ?");
        $stmt->execute([$phoneNumber]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            return $row;
        } else {
            return false;
        }        
        
    }
    
    public function middleware($text){
        //remove entries for going back and going to the main menu
        return $this->goBack($this->goToMainMenu($text));
    }

    public function goBack($text){
        //1*4*5*1*98*2*1234
        $explodedText = explode("*",$text);
        while(array_search(Util::$GO_BACK, $explodedText) != false){
            $firstIndex = array_search(Util::$GO_BACK, $explodedText);
            array_splice($explodedText, $firstIndex-1, 2);
        }
        return join("*", $explodedText);
    }

    public function goToMainMenu($text){
        //1*4*5*1*99*2*1234*99
        $explodedText = explode("*",$text);
        while(array_search(Util::$GO_TO_MAIN_MENU, $explodedText) != false){
            $firstIndex = array_search(Util::$GO_TO_MAIN_MENU, $explodedText);
            $explodedText = array_slice($explodedText, $firstIndex + 1);
        }
        return join("*",$explodedText);
    }

    public function menuViewResults($textArray,$phoneNumber){
        $level = count($textArray);
        if ($level == 1) {
            echo "CON Enter your pin \n";
        }else if ($level == 2) {
            echo "CON List of Quiz and choose Quiz Id \n";
            $stmt = $this ->conn->prepare("SELECT * FROM quiz");
            $stmt->execute();
            $response='';
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo $row['eid'].". " . $row['title'] . "\n";
            }
        }else if($level==3){
            $result=$this->isRegistered($phoneNumber);
            //echo "PIN: ".$textArray['1'];
            $pin=md5($textArray['1']);
            if($result['email'] && $result['password']==$pin){
                $email=$result['email'];
                $eid=$textArray['2'];
                //echo "eid: ".$eid;
                $stmt = $this ->conn->prepare("SELECT * FROM quiz where eid='$eid'");
                $stmt->execute();
                $resut2=$stmt->fetch(PDO::FETCH_ASSOC);
                foreach($resut2 as $dat){
                    $quiz=$resut2['title'];
                    //echo "hekl: ".$quiz;
                    $eidog=$resut2['eid'];
                    
                }
                if($eidog){
                    $stmt = $this->conn->prepare("SELECT * FROM history WHERE eid ='$eidog'");
                    $stmt->execute();
                    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    if($stmt->rowCount()){
                        $response = "CON Exam Results:\n";
                        foreach($rows as $row) {
                            $response .= "Exam: " . $quiz . ", Score: " . $row['score'] .'/5'." done on ".$row['date']. "\n";
                        }
                        echo $response;
                    }else{
                        echo "End No Quiz Attempted\n";
                    }
                    
                }else{
                    echo "End No Quiz Attempted\n";
                }
                
                
            }else{
                echo "END No quiz Attempted";
            }
            

        }else{
            echo "END Invalid input";
        } 
    }

    public function menuTakeExam($textArray,$phoneNumber) {
        $level = count($textArray);
        $lev=0;
        $lvv=0;
        $lv=0;
        $sum=0;
        if ($level == 1) {
            echo "CON Enter you Pin \n";
        }else if ($level == 2) {
            echo "CON Quiz List and Choose \n";
            $stmt = $this ->conn->prepare("SELECT * FROM quiz");
            $stmt->execute();
            $response='';
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                // Construct the response string
                echo $row['eid'].". " . $row['title'] . "\n";
            }
        } 
        elseif ($level == 3) {
            echo "CON Quiz Infor:";
            $eid=$textArray['2'];
            $stmt = $this ->conn->prepare("SELECT * FROM quiz where eid=eid");
            $stmt->execute();
            $response = '';
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                // Construct the response string
                echo $row['eid'].". " . $row['title'] . "\n";
                
            }
            echo "1. Start Now  \n";
            echo "2. Cancel \n";
            $response .=util::$GO_BACK . "Back \n";
            $response .=util::$GO_TO_MAIN_MENU ."main menu \n";
            echo $response;
        }elseif ($level == 4){
            
            if ($textArray[3] ==1) {
                $eid = $textArray['2'];
                $stmt = $this->conn->prepare("SELECT * FROM questions WHERE eid = :eid");
                $stmt->bindParam(':eid', $eid);
                $stmt->execute();
                $lv=1;
                echo "CON Attempt All questions \n ";
                echo "CON Choose QID(question number) and corresponding OPTID (option number) as an answer. \n \n  ";
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $lvv=count($row);
                    if ($lvv) {
                        echo "Q. ".$row["qid"]. ": ". $row["qns"]."\n";
                        $ab=1;
                        $stmt2 = $this->conn->prepare("SELECT * FROM options WHERE  qid=:qid");
                        $stmt2->bindParam(':qid', $row["qid"]);
                        $stmt2->execute();
                        while ($row2 = $stmt2->fetch(PDO::FETCH_ASSOC)) {
                        echo "Options:".$row2["optionid"]. " .". $row2["option"]."\n";
                        $ab++;
                        } 
                        
                    }
                    $lv++;
                    echo "\n";               

                }
            } 
        }else{
            $num=count($textArray);
            $marks=0;
            $fail=0;
            if ($num) {
                echo "All questions and options you responded:\n";
                $result=$this->isRegistered($phoneNumber);
                $email=$result['email'];
                $pin=md5($textArray['1']);
                if($result['pin']=$pin){
                    $n=3;
                    $n2=0;
                    $n3=0;
                    $isTrueop=0;
                    $isIncludedq=0;
                    $questionId=0;
                    $isIncludedq=0;
                    for ($n = 4; $n < $num ; $n++) {
                        if ($n % 2 == 0) {
                            // Check if question is included
                            $questionId = $textArray[$n];
                            $isIncluded = $this->isQuestionIncluded($questionId, $this->conn);
                            if ($isIncluded) {
                                $isIncludedq=$questionId;
                                //echo "QID: " . $questionId . " (Included)\n";
                                $n2++;
                                
                            } else {
                                echo "QID: " . $questionId . " invalid\n";
                            }
                        } else {
                            // Check if option is true
                            $optionId = $textArray[$n];
                            $isTrue = $this->isOptionTrue($optionId, $this->conn);
                            if ($isTrue) {
                                $isTrueop=$optionId;
                                //echo "OPID: " . $isTrueop . " (True)\n";
                                $n3++;
                            } else {
                                echo "OPID: " . $optionId . " Invalid\n";
                            }
                        }
                        if($n2!=0 && $n3!=0){
                            //echo "questionId ".$isIncludedq."\n";
                            $answer=$this->isOptionCorrect($isIncludedq, $this->conn);
                            //echo " answer: ".$answer."\n";
                            if($answer){
                                if($isTrueop==$answer){
                                    $marks +=1;
                                    //echo "marks ".$marks."\n";
                                }else{
                                    $fail +=1;
                                    //echo "marks ".$fail."\n";
                                }
                            }
                            $n2=0;
                            $n3=0;
                        }
                    } 
                    echo "marks: ".$marks ."\n"; 
                    echo "fail: ".$fail ."\n"; ;
                    //echo "email :"  .$email ."\n"; 
                    $eid = $textArray['2'];
                    $level=$marks+$fail;
                    $inst = $this->conn->prepare("INSERT INTO history (email, eid, score, level, sahi, wrong, date) VALUES (?, ?, ?, ?, ?, ?, NOW())");

                    // Bind parameters to the placeholders
                    $inst->bindParam(1, $email);
                    $inst->bindParam(2, $eid);
                    $inst->bindParam(3, $marks);
                    $inst->bindParam(4, $level);
                    $inst->bindParam(5, $marks); 
                    $inst->bindParam(6, $fail); 
                    
                    // Execute the statement
                    $inst->execute();                
                    if($inst){
                        echo "END Successfull to attempty quiz of ".$level." questions you get ".$marks."/5"." marks";
                    }
                }else{
                    echo "END Invalid Pin";
                }
                
            }
        }
    } 

}
?>